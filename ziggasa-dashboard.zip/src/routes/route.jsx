import { Outlet } from "react-router-dom";
import AppLayout from "../layouts";

export default function Root() {
  return (
    <AppLayout>
      <div>
        <Outlet />
      </div>
    </AppLayout>
  );
}
