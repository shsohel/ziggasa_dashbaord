export const userBasicInfoModal = {
  _id: null,
  name: "",
  email: "",
  password: "",
  newPassword: "",
  confirmPassword: "",
  isActive: true,
  image: "default-user.png",
  role: { label: "Admin", value: "Admin" },
};

export const userRole = [
  { label: "Admin", value: "Admin" },
  { label: "User", value: "User" },
];
