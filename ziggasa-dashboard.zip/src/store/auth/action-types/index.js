export const GET_AUTH_USER = 'GET_AUTH_USER';
